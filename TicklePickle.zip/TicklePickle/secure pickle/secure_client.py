import pickle
import json
import hashlib
import hmac


class User(object):
	
	def fun(name,password):
		s = {"username":name,"password":password}
		serialized = pickle.dumps(s)
		#calculate the signature and use digest to get the bytes
	
		KEY = b'secret'
		signature = hmac.new(KEY, serialized, hashlib.sha256).digest()
		with open("users.json", 'wb') as file_object:
		#Adding the signature to the data
				file_object.write(signature + serialized)
	if __name__ == '__main__':
			u = input("Username : ")
			p = input("Password : ")
			yo_fun = fun(u,p)



  













    