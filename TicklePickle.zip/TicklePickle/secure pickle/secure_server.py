import pickle
import json
import hashlib
import hmac

with open("users.json", 'rb') as file_object:
    KEY = b'secret'
    raw_data = file_object.read()
    if(len(raw_data) >= len(signature)): #if the raw_data has at least the signature
        read_signature = raw_data[:len(signature)]
        read_data = raw_data[len(signature):]
        computed_signature = hmac.new(KEY, read_data, hashlib.sha256).digest()
    if hmac.compare_digest(computed_signature, read_signature):
        userDeserialized = pickle.loads(read_data)

